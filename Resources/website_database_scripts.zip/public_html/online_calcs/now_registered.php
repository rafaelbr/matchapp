<?php
  include ('header.html');
  include ('constants.php');

  echo "<div id='content'>";
  echo "<h1>" . YOUR_URL . " Database Registration</h1>";
  echo "<br><p><strong>Thank you for registering - you are now a member.</strong></p>";
  echo "<br><p><a href='signup_login.php'>Click here</a> to return to the login page and sign in as a current member</p>";
  echo "<p>&nbsp;</p>";
  echo "</div>";

  include ('footer.html');
?>
