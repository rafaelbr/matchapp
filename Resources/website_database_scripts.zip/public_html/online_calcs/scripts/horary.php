<?php
  echo "This script has been reserved due to another person's request.<br>";
?>
