Speedometer.themes.kitsch = {
  dial: 'Green',
  rim: 'Purple',
  thresh: 'Blue',
  center: 'Blue',
  nose: 'Yellow',
  hand: 'Blue',
  handShine: 'LightBlue',
  handShineTo: 'Blue',
  ticks: 'Purple',
  marks: 'White',
  strings: 'Red',
  digits: 'Green',
  font: 'Times'
}
