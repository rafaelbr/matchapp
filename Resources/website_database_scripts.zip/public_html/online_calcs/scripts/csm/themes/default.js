Speedometer.themes['default'] = {
  dial       : 'White',
  rim        : 'SlateGray',
  rimArc     : 'Gainsboro',
  thresh     : 'LawnGreen',
  center     : 'Black',
  nose       : 'SlateGray',
  hand       : 'Red',
  handShine  : 'SlateGray',
  handShineTo: 'Red',
  ticks      : 'Black',
  marks      : 'Black',
  strings    : 'Black',
  digits     : 'Black',
  font       : 'Sans-Serif'
};
